<?php
/**
 * @copyright	Copyright (c) 2016 Innovision Lab (http://nnovisionlab.com). All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

/**
 * PCCADDIE - PCCADDIE Manager Plugin
 *
 * @package		Joomla.Plugin
 * @subpakage	Content
 */
class plgContentPCCADDIEManager extends JPlugin {

	/**
	 * Constructor.
	 *
	 * @param 	$subject
	 * @param	array $config
	 */
	function __construct(&$subject, $config = array()) {
		
		// call parent constructor
		parent::__construct($subject, $config);
	}

	public function onContentPrepare($context, &$article, &$params, $page = 0)
	{
		$pc_user_data  = JFactory::getApplication()->input->cookie;
		if(isset($_POST['pcco-user']) && isset($_POST['pcco-pass'])){
			
			$userId = $_POST['pcco-user'];
			$userpassword = $_POST['pcco-pass'];
			$user = $this->params->get('xmluser');
			$password = $this->params->get('xmlpassword');
			$club = $this->params->get('xml_club');
			$guest_url = $this->params->get('guest_url');
			$member_url= $this->params->get('member_url');

			$url = "https://www.pccaddie.net/interface/crm_checkuser.php?xmluser=$user&xmlpassword=$password&xmlclub=$club&userid=$userId&userpassword=$userpassword&forcecheck=1&json=1";

			//$url = "https://www.pccaddie.net/interface/crm_checkuser.php?xmluser=joomlatest&xmlpassword=J00ml4&xmlclub=0497100&userid=harry@hoppel.de&userpassword=H0pp3L&forcecheck=1";

			$JSON = file_get_contents($url);
			
			
			$data = json_decode($JSON,true);
			if($data['RESULT'] !== "OK"){
				$article->text = JFactory::getApplication()->enqueueMessage($data['DESCRIPTION'], 'error').$article->text;
			}else{
				$pc_user_data->set($name = 'PC_FIRSTNAME', $value = $data['FIRSTNAME'], $expire = 0);
				$pc_user_data->set($name = 'PC_NAME', $value = $data['NAME'], $expire = 0);
				$pc_user_data->set($name = 'PC_GENDER', $value = $data['GENDER'], $expire = 0);
				$pc_user_data->set($name = 'PC_IS_MEMBER', $value = $data['IS_MEMBER'], $expire = 0);
				if(isset($data['ZUSATZ'])){
					$pc_user_data->set($name = 'PC_ZUSATZ', $value = $data['ZUSATZ'], $expire = 0);
				}else{
					$pc_user_data->set($name = 'PC_ZUSATZ', $value = 'guest', $expire = 0);
				}
				$pc_user_data->set($name = 'PC_SSOHASH', $value = $data['SSOHASH'], $expire = 0);
				$iv_daten = explode("&daten=",$data['SSOHASH']);
				$pc_user_data->set($name = 'PC_IV', $value = substr($iv_daten[0],3), $expire = 0);
				$pc_user_data->set($name = 'PC_DATEN', $value = $iv_daten[1], $expire = 0);
				
			}
			
		}else if(isset($_POST['pcco_logout'])){
			$pc_user_data->set('PC_FIRSTNAME', null, time() - 1);
			$pc_user_data->set('PC_NAME', null, time() - 1);
			$pc_user_data->set('PC_GENDER',null, time() - 1);
			$pc_user_data->set('PC_IS_MEMBER', null, time() - 1);
			$pc_user_data->set('PC_ZUSATZ', null, time() - 1);
			$pc_user_data->set('PC_SSOHASH', null, time() - 1);
			$pc_user_data->set('PC_FULL_NAME', null,time() - 1);
			$pc_user_data->set('PC_IV', null,time() - 1);
			$pc_user_data->set('PC_DATEN', null,time() - 1);
		}
		
		
		$article->text = str_replace("{pc-container}", $this->pc_iframe(),$article->text);
		if( $this->pc_login_check()== '1'){
			$article->text = str_replace("{pc-login}", $this->pc_profile_page(),$article->text);
		}else{
			$article->text = str_replace("{pc-login}", $this->pc_login_form(),$article->text);
		}
		

	}

	public function pc_login_form(){
		$this->pc_init_data();
		/*$form_layout = '<div class="loginmodal-container">
			<h1>'.JText::_("LOGIN_TO_YOUR_ACCOUNT").'</h1><br>
		  <form action="'.JURI::current().'" method="POST">
			<input type="text" required name="pc-user" placeholder="'.JText::_("USERNAME").'">
			<input type="password" required name="pc-pass" placeholder="'.JText::_("PASSWORD").'">
			<input type="submit" name="login" class="login loginmodal-submit" value="'.JText::_("LOGIN").'">
		  </form>
		</div>';*/
		$form_layout = '<div class="pcco-container">
    <h1 class="pcco-headline">Anmeldung</h1>

    <form action="'.JURI::current().'" method="post">
        <div class="row">
            <div class="col-sm-12">
                <div class="formgroup">
                    <!-- <label for="pcco-user">Userame:</label> -->
                    <input type="text" class="form-control pcco-input" name="pcco-user" id="pcco-user" placeholder="E-Mail / Benutzername">
                </div>
            </div>

            <div class="col-sm-12">
                <div class="form-group">
                    <!-- <label for="pcco-pass">Password:</label> -->
                    <input type="password" class="form-control pcco-input" name="pcco-pass" id="pcco-pass" placeholder="Passwort">
                </div>
            </div>

            <div class="col-sm-12">
                <button type="submit" class="btn btn-default pcco-button">Login</button>
            </div>
        </div>
    </form>
</div>';
		return $form_layout;
	}

	public function pc_greeting(){
		$pc_user_data  = JFactory::getApplication()->input->cookie;
		$pc_full_name = '';
		if($this->pc_login_check() == '1'){
			if($pc_user_data->get('PC_GENDER')=="M"){
				$pc_full_name = JText::_("PC_HI_MR").$pc_user_data->get('PC_FIRSTNAME')." ".$pc_user_data->get('PC_NAME');
			}else{
				$pc_full_name = JText::_("PC_HI_MS").$pc_user_data->get('PC_FIRSTNAME')." ".$pc_user_data->get('PC_NAME');
			}
		}
		return $pc_full_name;
	}

	public function pc_profile_page(){
		$this->pc_init_data();
		/*$form_layout = '<div class="logoutmodal-container">
			<h1>'.$this->pc_greeting().'</h1><br>
		  <form action="'.JURI::current().'" method="POST">
			<input type="submit" name="pc_logout" class="login loginmodal-submit" value="'.JText::_("LOGOUT").'">
		  </form>
		</div>';*/
		$form_layout = '<div class="pcco-container">
					    <h1 class="pcco-headline">'.$this->pc_greeting().'</h1>

					    <form action="'.JURI::current().'" method="post">
					        <div class="row">
					            <div class="col-sm-12">
					            	<input type="hidden" name="pcco_logout" value="logout">
					                <button type="submit" class="btn btn-default pcco-button">Logout</button>
					            </div>
					        </div>
					    </form>
					</div>';
		return $form_layout;
	}

	public function pc_login_check(){
		$pc_user_data  = JFactory::getApplication()->input->cookie;
		if( $pc_user_data->get($name = 'PC_FIRSTNAME') !=null &&
			$pc_user_data->get($name = 'PC_NAME') != null &&
			$pc_user_data->get($name = 'PC_GENDER') != null &&
			$pc_user_data->get($name = 'PC_IS_MEMBER') != null &&
			$pc_user_data->get($name = 'PC_ZUSATZ') != null &&
			$pc_user_data->get($name = 'PC_SSOHASH') != null){
			return "1";
		}else{
			return "0";
		}
	}

	public function pc_init_data(){
		$doc = JFactory::getDocument();
		$lang = JFactory::getLanguage();
		$lang->load('plg_content_pccaddiemanager', JPATH_ADMINISTRATOR);
		$doc->addStyleSheet(JURI::root()."plugins/content/pccaddiemanager/css/pc-style.css");
		$doc->addScript(JURI::root()."plugins/content/pccaddiemanager/js/pc-script.js");
	}

	public function pc_iframe(){
		if(isset($_GET["turnierid"])){
			$turnierid = $_GET["turnierid"];
		}
		$this->pc_init_data();
		$pc_user_data  = JFactory::getApplication()->input->cookie;
		$iframe_url = '';
		$iframe_url = "https://www.pccaddie.net/clubs/".$this->params->get('xml_club')."/app.php?cat=ts_calendar_turn_only&iv=".$pc_user_data->get($name = 'PC_IV')."&daten=".$pc_user_data->get($name = 'PC_DATEN')."&sub=register&id=".$turnierid;

		$iframe_content = '<div id="contentwrapright" class="fright">
		<iframe style="border: medium none;overflow:hidden"  height="700" id="pccoframe" src="'.$iframe_url.'" width="100%" scrolling="auto"></iframe>
		</div>';
		return $iframe_content;
	}
}