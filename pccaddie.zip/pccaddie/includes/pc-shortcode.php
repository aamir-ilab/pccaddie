<?php
function pccaddie_func( $atts ) {
	$options = get_option( 'pccaddie_options' );
	$startdate = Date('Y-m-d', strtotime($options['datumvon']." days"));
	$enddate = Date('Y-m-d', strtotime($options['datumbis']." days"));

	$url = "https://www.pccaddie.net/interface/platzbelegung.php?user=".$options['pcuser']."&password=".$options['pcpassword']."&club=".$options['pcclub']."&datumvon=".$startdate."&datumbis=".$enddate."&minentries=".$options['pcminentries']."&showjson=1&ignoremax99=".$options['pcignoremax99']."&dayinfo=0";

	$JSON = file_get_contents($url);
	$data = json_decode($JSON,true);
 
	if(isset($data)){
		foreach ($data as $key => $value) {	
			if(is_array($value)){
				$explodedDatum = explode("-",$value['DATUM']);
				$explodedDATUM_ENDE = explode("-",$value['DATUM_ENDE']);
				
				// if ? then add &
				if (strpos($options['pclink'],'?') !== false) {
				    $pcurl = $options['pclink']."&";
				} else {
				    $pcurl = $options['pclink']."?";
				}


				?>
				<div class="snapshot-col">	
					<div class="snapshot-default">
						<p class="snapshot-date"><span class="day"><?php echo $explodedDatum['2'];?></span><span class="month">/<?php echo $explodedDatum['1'];?></span>
						<!-- <span class="year">/2016</span> -->
						</p>
						<p class="snapshot-name"><?php echo $value['TURNIERNAME'];?></p>
						<p class="snapshot-link"><a href="<?php echo $pcurl;?>turnierid=<?php echo $value['TURNIERID']?>&pccmobileclubID=<?php echo $options['pcclub'];?>"><?php echo $options['pcbuttonText'];?></a></p>
					</div>
					<div class="snapshot-appear">
						<p class="snapshot-date"><span class="day"><?php echo $explodedDatum['2'];?></span><span class="month">/<?php echo $explodedDatum['1'];?></span><span class="year">/<?php echo $explodedDatum['0'];?></span></p>
						<p class="snapshot-name"><?php echo $value['TURNIERNAME'];?></p>
						<p class="snapshot-info"><?php echo $value['STARTINFO'];?></p>
						<p class="snapshot-meldung"><?php echo $value['MELDUNG_AB'];?></p>
						<p><?php echo $value['MELDESCHLUSS'];?></p>
						<p><?php echo $value['TURNIERART'];?></p>
						<p><?php echo 'End Time'." ".$explodedDATUM_ENDE['1']."-".$explodedDATUM_ENDE['2']."-".$explodedDATUM_ENDE['0']." ".$value['TIME_END'];?></p>
						<p><?php echo 'Start Time'." ".$value['TIME_START'];?></p>
						<p class="snapshot-link"><a href="<?php echo $pcurl;?>turnierid=<?php echo $value['TURNIERID']?>&pccmobileclubID=<?php echo $options['pcclub'];?>"><?php echo $options['pcbuttonText'];?></a></p>

					</div>
				</div>
				<?php
			}
		}
	}
	
}
add_shortcode( 'pccaddie', 'pccaddie_func' );


function pccaddie_login()
{
	$classpcc = new Pccaddie;
	$classpcc->onContentPrepare();
}

add_shortcode( 'pclogin', 'pccaddie_login' );



function pccaddie_ifram(){
	$classpcc = new Pccaddie;
	echo $classpcc->pc_iframe();
}

add_shortcode( 'pcifram', 'pccaddie_ifram' );