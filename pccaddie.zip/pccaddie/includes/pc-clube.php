<?php

/**
 * Pccaddie Page Example
 */
function pccaddie_menu()
{
  add_theme_page( 'Pccaddie', 'Pccaddies', 'manage_options', 'pccaddie_options.php', 'pccaddie_page');  
}
add_action('admin_menu', 'pccaddie_menu', 10, 1);

/**
 * Callback function to the add_theme_page
 * Will display the Pccaddies page
 */ 
function pccaddie_page()
{
?>
    <div class="section panel">
      <h1>Pccaddies</h1>
      <form method="post" enctype="multipart/form-data" action="options.php">
        <?php 
          settings_fields('pccaddie_options'); 
        
          do_settings_sections('pccaddie_options.php');
        ?>
            <p class="submit">  
                <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />  
            </p>  
            
      </form>
     
    </div>
    <?php
}


/**
 * Register the settings to use on the Pccaddies page
 */
add_action( 'admin_init', 'pc_register_settings' );

/**
 * Function to register the settings
 */
function pc_register_settings()
{
    // Register the settings with Validation callback
    register_setting( 'pccaddie_options', 'pccaddie_options', 'pc_validate_settings' );

    // Add settings section
    add_settings_section( 'pc_text_section', '', '', 'pccaddie_options.php' );

    // Create textbox field
    $field_args = array(
      'type'      => 'text',
      'id'        => 'datumbis',
      'name'      => 'datumbis',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'datumbis',
      'placeholder' => '-10',
      'class'     => 'css_class'
    );

    $field_args2 = array(
      'type'      => 'text',
      'id'        => 'datumvon',
      'name'      => 'datumvon',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'datumvon',
      'placeholder' => '+10',
      'class'     => 'css_class'
    );

    $field_args3 = array(
      'type'      => 'text',
      'id'        => 'pcuser',
      'name'      => 'pcuser',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'pcuser',
      'placeholder' => 'test',
      'class'     => 'css_class'
    );

     $field_args4 = array(
      'type'      => 'password',
      'id'        => 'pcpassword',
      'name'      => 'pcpassword',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'pcpassword',
      'placeholder' => 'password',
      'class'     => 'css_class'
    );

      $field_args5 = array(
      'type'      => 'text',
      'id'        => 'pcclub',
      'name'      => 'pcclub',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'pcclub',
      'placeholder' => '12345',
      'class'     => 'css_class'
    );

    $field_args6 = array(
      'type'      => 'text',
      'id'        => 'pcignoremax99',
      'name'      => 'pcignoremax99',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'pcignoremax99',
      'placeholder' => '1 or 0',
      'class'     => 'css_class'
    );

    $field_args7 = array(
      'type'      => 'text',
      'id'        => 'pcminentries',
      'name'      => 'pcminentries',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'pcminentries',
      'placeholder' => '4',
      'class'     => 'css_class'
    );

    $field_args8 = array(
      'type'      => 'text',
      'id'        => 'pcbuttonText',
      'name'      => 'pcbuttonText',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'pcbuttonText',
      'placeholder' => 'Submit',
      'class'     => 'css_class'
    );


    $field_args9 = array(
      'type'      => 'textarea',
      'id'        => 'pclink',
      'name'      => 'pclink',
      'desc'      => '',
      'std'       => '',
      'label_for' => 'pclink',
      'placeholder' => 'http://www.example.com',
      'class'     => 'css_class'
    );

     add_settings_field( 'datumbis', 'From date', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args2 );
     add_settings_field( 'datumvon', 'to date', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args );
    add_settings_field( 'pcuser', 'Username', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args3 );
    add_settings_field( 'pcpassword', 'Password', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args4 );
    add_settings_field( 'pcclub', 'Club No', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args5 );
    add_settings_field( 'pcignoremax99', 'Ignore max 99', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args6 );
    add_settings_field( 'pcminentries', 'Min Entries', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args7 );
    add_settings_field( 'pcbuttonText', 'Button Text', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args8 );
    add_settings_field( 'pclink', 'Display link', 'pc_display_setting', 'pccaddie_options.php', 'pc_text_section', $field_args9 );
}

function pc_display_setting($args)
{
    extract( $args );

    $option_name = 'pccaddie_options';
    $options = get_option( $option_name );
    if($type =='textarea'){
      echo "<textarea  cols='30' rows='4' class='regular-text$class' name='" . $option_name . "[$id]' placeholder='$placeholder'>$options[$id]</textarea>";
    }else{
      echo "<input class='regular-text$class' type='$type' id='$id' name='" . $option_name . "[$id]' placeholder='$placeholder' value='$options[$id]' />"; 
    }
}

function pc_validate_settings($input)
{
  foreach($input as $k => $v)
  {
    $newinput[$k] = trim($v);
    
    // // Check the input is a letter or a number
    // if(!preg_match('/^[A-Z0-9 _]*$/i', $v)) {
    //   $newinput[$k] = '';
    // }
  }

  return $newinput;
}