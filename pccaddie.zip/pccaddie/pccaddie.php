<?php

/**
 *
 * @wordpress-plugin
 * Plugin Name:       pccaddie
 * Plugin URI:        #
 * Description:       this plugin is use only for testing
 * Version:           1.0.0
 * Author:            iLab
 * Author URI:        #
 * License:           GPL-2.0+
 * License URI:       #
 * Text Domain:       #
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

//include files
include_once( 'includes/pc-clube.php' );
include_once( 'includes/class-pccaddie.php' );
include_once( 'includes/pc-shortcode.php' );



function pc_scripts()
{
    // Register the script like this for a plugin:
    wp_register_style( 'pc-style', plugin_dir_url( __FILE__ ) .'assets/css/pc-style.css');
 
    // For either a plugin or a theme, you can then enqueue the script:
   	wp_enqueue_style( 'pc-style' );
}
add_action( 'wp_enqueue_scripts', 'pc_scripts' );