<?php
defined('_JEXEC') or die;
if($module->showtitle){
	echo "<h3 class='snapshot-title'>".$module->title."</h3>";
}
if(isset($data)){
	?>
	<div class="snapshot-listing">	
		<?php
		foreach ($data as $key => $value) {	
			if(is_array($value)){
				$explodedDatum = explode("-",$value['DATUM']);
				$explodedDATUM_ENDE = explode("-",$value['DATUM_ENDE']);
				?>
					<p class="snapshot-listing-date"><?php echo $explodedDatum['2'];?>.<?php echo $explodedDatum['1'];?>.<?php echo $explodedDatum['0'];?></p>
					<p class="snapshot-listing-name"><strong><?php echo $value['TURNIERNAME'];?></strong></p>
					<p class="snapshot-listing-info"><?php echo $value['STARTINFO'];?></p>
					<p class="snapshot-listing-meldung"><?php echo $value['MELDUNG_AB'];?></p>
					<p><?php echo $value['MELDESCHLUSS'];?></p>
					<p><?php echo $value['TURNIERART'];?></p>
					<p><?php echo JText::_('End Time')." ".$explodedDATUM_ENDE['1'].".".$explodedDATUM_ENDE['2'].".".$explodedDATUM_ENDE['0']." ".$value['TIME_END'];?></p>
					<p><?php echo JText::_('Start Time')." ".$value['TIME_START'];?></p>
					<p class="snapshot-listing-link"><a href="<?php echo $link;?>?turnierid=<?php echo $value['TURNIERID']?>&pccmobileclubID=<?php echo $club;?>"><?php echo $buttonText;?></a></p>
					 
				<hr/>
				<?php
			}
		}
		?>
	</div>
	<?php
}else{
	echo JFactory::getApplication()->enqueueMessage($JSON, 'error');
}