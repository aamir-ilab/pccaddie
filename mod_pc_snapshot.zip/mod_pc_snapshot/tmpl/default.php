<?php
defined('_JEXEC') or die;
if($module->showtitle){
	echo "<h3 class='snapshot-title'>".$module->title."</h3>";
}
if(isset($data)){

	foreach ($data as $key => $value) {	
		if(is_array($value)){
			$explodedDatum = explode("-",$value['DATUM']);
			$explodedDATUM_ENDE = explode("-",$value['DATUM_ENDE']);
			?>
			<div class="snapshot-col">	
				<div class="snapshot-default">
					<p class="snapshot-date"><span class="day"><?php echo $explodedDatum['2'];?></span><span class="month">/<?php echo $explodedDatum['1'];?></span>
					<!-- <span class="year">/2016</span> -->
					</p>
					<p class="snapshot-name"><?php echo $value['TURNIERNAME'];?></p>
					<p class="snapshot-link"><a href="<?php echo $link;?>?turnierid=<?php echo $value['TURNIERID']?>&pccmobileclubID=<?php echo $club;?>"><?php echo $buttonText;?></a></p>
				</div>
				<div class="snapshot-appear">
					<p class="snapshot-date"><span class="day"><?php echo $explodedDatum['2'];?></span><span class="month">/<?php echo $explodedDatum['1'];?></span><span class="year">/<?php echo $explodedDatum['0'];?></span></p>
					<p class="snapshot-name"><?php echo $value['TURNIERNAME'];?></p>
					<p class="snapshot-info"><?php echo $value['STARTINFO'];?></p>
					<p class="snapshot-meldung"><?php echo $value['MELDUNG_AB'];?></p>
					<p><?php echo $value['MELDESCHLUSS'];?></p>
					<p><?php echo $value['TURNIERART'];?></p>
					<p><?php echo JText::_('End Time')." ".$explodedDATUM_ENDE['1']."-".$explodedDATUM_ENDE['2']."-".$explodedDATUM_ENDE['0']." ".$value['TIME_END'];?></p>
					<p><?php echo JText::_('Start Time')." ".$value['TIME_START'];?></p>
					<p class="snapshot-link"><a href="<?php echo $link;?>?turnierid=<?php echo $value['TURNIERID']?>&pccmobileclubID=<?php echo $club;?>"><?php echo $buttonText;?></a></p>

				</div>
			</div>
			<?php
		}
	}
}else{
	echo JFactory::getApplication()->enqueueMessage($JSON, 'error');
}