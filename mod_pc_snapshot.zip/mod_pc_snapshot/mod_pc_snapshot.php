<?php
/**
 * @copyright	Copyright © 2016 - All rights reserved.
 * @license		GNU General Public License v2.0
 */
defined('_JEXEC') or die;
$doc = JFactory::getDocument();

$doc->addStyleSheet(JURI::root()."modules/mod_pc_snapshot/assets/css/style.css");
$doc->addScript(JURI::root()."modules/mod_pc_snapshot/assets/js/script.js");
ini_set("allow_url_fopen", 1);
$pc_plugin 			= JPluginHelper::getPlugin('content', 'pccaddiemanager');
$pc_plugin_params 	= new JRegistry($pc_plugin->params);
$datumbis 			= date("Y-m-d", strtotime($params->get('datumbis')." day"));;
$datumvon			= date("Y-m-d", strtotime($params->get('datumvon')." day"));
$user				= $pc_plugin_params->get('xmluser');
$password			= $pc_plugin_params->get('xmlpassword');
$club 				= $pc_plugin_params->get('xml_club');
$ignoremax99 		= $params->get('ignoremax99');
$minentries			= $params->get('minentries');
$buttonText 		= $params->get('btntext');
$link  				= $params->get('display_link');
$url 				= "https://www.pccaddie.net/interface/platzbelegung.php?user=$user&password=$password&club=$club&datumvon=$datumvon&datumbis=$datumbis&minentries=$minentries&showjson=1&ignoremax99=$ignoremax99&dayinfo=0";
$JSON = file_get_contents($url);
$data = json_decode($JSON,true);
require JModuleHelper::getLayoutPath('mod_pc_snapshot', $params->get('modlayout'));