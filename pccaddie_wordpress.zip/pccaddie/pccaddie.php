<?php

/**
 *
 * @wordpress-plugin
 * Plugin Name:       PC CADDIE://online Wordpress Plugin
 * Plugin URI:        #
 * Description:       Enables Snapshot, SSO and IFRAME-Support for PC CADDIE
 * Version:           1.0.5
 * Author:            PC CADDIE://online GmbH & Co. KG, D-23847 Poelitz
 * Author URI:        https://mobile.pccaddie.net
 * License:           GPL-2.0+
 * License URI:       #
 * Text Domain:       #
 * Domain Path:       /languages
 */

//  Version History
//  1.0.5   26.09.17    Updates Access Pages
//  1.0.4   25.09.17    Updates Functions
//  1.0.3   25.09.17    Updates
//  1.0.2   25.09.17    Updates for CSS
//  1.0.1   10.09.17    Added new Functions
//  1.0.0   28.08.17    Basic Functions for Wordpress 4.8.1

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

// include files
include_once( 'includes/pc-clube.php' );
include_once( 'includes/class-pccaddie.php' );
include_once( 'includes/pc-shortcode.php' );
include_once( 'includes/restrication.php' );

// Define BASE_URL
define ("PCCO_BASE_URL", "https://www.pccaddie.net");


function pc_scripts()
{
    // Register the script like this for a plugin:
    wp_register_style( 'pc-style', plugin_dir_url( __FILE__ ) .'assets/css/pc-style.css');
 
    // For either a plugin or a theme, you can then enqueue the script:
   	wp_enqueue_style( 'pc-style' );
}
add_action( 'wp_enqueue_scripts', 'pc_scripts' );