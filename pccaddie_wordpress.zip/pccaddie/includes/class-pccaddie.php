<?php
ob_start();
class Pccaddie{


	function __construct()
	{
		global $wp;
		$current_url = home_url(add_query_arg(array(),$wp->request));
		$this->pc_init_data();
	}

	//login form
	public function pc_login_form()
	{
		return'
		<div class="pcco-container">
		    <h1 class="pcco-headline">Anmeldung</h1>

		    <form action="" method="post">
		        <div class="row">
		            <div class="col-sm-12">
		                <div class="formgroup">
		                    <!-- <label for="pcco-user">Userame:</label> -->
		                    <input type="text" class="form-control pcco-input" name="pcco-user" id="pcco-user" placeholder="E-Mail / Benutzername">
		                </div>
		            </div>

		            <div class="col-sm-12">
		                <div class="form-group">
		                    <!-- <label for="pcco-pass">Password:</label> -->
		                    <input type="password" class="form-control pcco-input" name="pcco-pass" id="pcco-pass" placeholder="Passwort">
		                </div>
		            </div>

		            <div class="col-sm-12">
		                <button type="submit" class="btn btn-default pcco-button">Login</button>
		            </div><br>
		        </div>
		    </form>
		</div>';
	}

	//profile page
	public function pc_profile_page()
    {
		$this->pc_init_data();
		if($this->get('PC_GENDER')=="M")
		{
			$fullname =  "Hallo " .$this->get($name = 'PC_FIRSTNAME') .' '.$this->get($name = 'PC_NAME');
		}else{
			$fullname =  "Hallo " .$this->get($name = 'PC_FIRSTNAME') .' '.$this->get($name = 'PC_NAME');
		}

		$profile = '
		<div class="pcco-container">
		    <h1 class="pcco-headline"> </h1>
		    <form action="" method="post">
		        <div class="row">
		            <div class="col-sm-12">

		            	<h2>'. $fullname . '</h2>
		            	<input type="hidden" name="pcco_logout" value="logout">
		                <input type="submit" class="btn btn-default pcco-button" value="Logout">
		            </div>
		        </div>
		    </form>
		</div>';
		return $profile;
	}

	public function onContentPrepare()
	{
		
		if(isset($_POST['pcco-user']) && isset($_POST['pcco-pass'])){
			$options = get_option( 'pccaddie_options' );

			$userId 		= $_POST['pcco-user'];
			$userpassword 	= $_POST['pcco-pass'];
			$user 			= $options['pcuser'];
			$password 		= $options['pcpassword'];
			$club 			= $options['pcclub'];


			$url = "https://www.pccaddie.net/interface/crm_checkuser.php?xmluser=$user&xmlpassword=$password&xmlclub=$club&userid=$userId&userpassword=$userpassword&forcecheck=1&json=1";

			$JSON = file_get_contents($url);
			
			$data = json_decode($JSON,true);
			if($data['RESULT'] !== "OK"){
				echo "username or password is wrong";
			}else{
				$this->set($name = 'PC_FIRSTNAME', $value = $data['FIRSTNAME'], $expire = 0);
				$this->set($name = 'PC_NAME', $value = $data['NAME'], $expire = 0);
				$this->set($name = 'PC_GENDER', $value = $data['GENDER'], $expire = 0);
				$this->set($name = 'PC_IS_MEMBER', $value = $data['IS_MEMBER'], $expire = 0);
				if(isset($data['ZUSATZ'])){
					$this->set($name = 'PC_ZUSATZ', $value = $data['ZUSATZ'], $expire = 0);
				}else{
					$this->set($name = 'PC_ZUSATZ', $value = 'guest', $expire = 0);
				}
				$this->set($name = 'PC_SSOHASH', $value = $data['SSOHASH'], $expire = 0);
				$iv_daten = explode("&daten=",$data['SSOHASH']);
				$this->set($name = 'PC_IV', $value = substr($iv_daten[0],3), $expire = 0);
				$this->set($name = 'PC_DATEN', $value = $iv_daten[1], $expire = 0);
				header('Location: '.  esc_url(the_permalink()) );
			}
		}else if(isset($_POST['pcco_logout'])){
			$this->set('PC_FIRSTNAME', null, time() - 1);
			$this->set('PC_NAME', null, time() - 1);
			$this->set('PC_GENDER',null, time() - 1);
			$this->set('PC_IS_MEMBER', null, time() - 1);
			$this->set('PC_ZUSATZ', null, time() - 1);
			$this->set('PC_SSOHASH', null, time() - 1);
			$this->set('PC_FULL_NAME', null,time() - 1);
			$this->set('PC_IV', null,time() - 1);
			$this->set('PC_DATEN', null,time() - 1);
			header('Location: '.  esc_url(the_permalink()) );
		}

		// if user has login
		if( $this->pc_login_check()== '1'){
			return $this->pc_profile_page();
		}else{
			return $this->pc_login_form();
		}
	}

	public function pc_login_check(){
		if( $this->get($name = 'PC_FIRSTNAME') !=null &&
			$this->get($name = 'PC_NAME') != null &&
			$this->get($name = 'PC_GENDER') != null &&
			$this->get($name = 'PC_IS_MEMBER') != null &&
			$this->get($name = 'PC_ZUSATZ') != null &&
			$this->get($name = 'PC_SSOHASH') != null){
			return "1";
		}else{
			return "0";
		}
	}


	/**
	 * Create cookie.
	*/
	
	public function set($name, $value = '', $expire = 0) {
		return setcookie($name, $value, $expire);
	}

	public function get($name) {
	    $return = true;
        isset($_COOKIE[$name]) ?: $return = false;
        !empty($_COOKIE[$name]) ?: $return = false;
        return $return ? $_COOKIE[$name] : $return;
	}

	public function pc_iframe($type=null)
    {
		if(isset($_REQUEST["turnierid"])){
			$turnierid = "&id=".$_REQUEST["turnierid"];
		}else{
			$turnierid = "";
		}

        $options    = get_option( 'pccaddie_options' );

        if(isset($_REQUEST["pccmobileclubID"])){
			$pccmobileclubID = $_REQUEST["pccmobileclubID"];
		}elseif (!empty($options['pcclub']))
        {
            $pccmobileclubID = $options['pcclub'];
        }
		else{
			$pccmobileclubID = "";
		}
		
		$this->pc_init_data();


		switch ($type)
        {
            case 'teetimes':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/app.php?cat=tt_timetable_course&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN');
                break;

            case 'trainer':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/app.php?cat=tt_timetable_trainer&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN');
                break;

            case 'trainerweek':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/app.php?cat=tt_timetable_trainer_daylist&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN');
                break;

            case 'calendar':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/app.php?cat=ts_calendar&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN').$turnierid;
                break;

            case 'startlist':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/app.php?cat=ts_startlist&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN').$turnierid;
                break;

            case 'resultlist':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/app.php?cat=ts_resultlist&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN').$turnierid;
                break;

            case 'hcplist':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/hcp.php?iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN');
                break;

            case 'memberlist':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/crm.php?action=memberlist&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN');
                break;

            case 'memberdata':
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/crm.php?action=edit&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN');
                break;

            case 'entry':
            default:
                $iframe_url = PCCO_BASE_URL."/clubs/".$pccmobileclubID."/app.php?cat=ts_calendar&iv=".$this->get($name = 'PC_IV')."&daten=".$this->get($name = 'PC_DATEN')."&sub=register".$turnierid;
                break;
        }

		$iframe_content = '<div id="contentwrapright" class="fright">
		<iframe style="border: medium none;overflow:hidden"  height="700" id="pccoframe" src="'.$iframe_url.'" width="100%" scrolling="auto"></iframe>
		</div>';
		return $iframe_content;
	}

	function pc_init_data()
    {
		#include script and styles
	}

}

?>