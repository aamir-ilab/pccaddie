<?php
function pccaddie_func( $atts )
{
	$options = get_option( 'pccaddie_options' );
	$startdate = Date('Y-m-d', strtotime($options['datumvon']." days"));
	$enddate = Date('Y-m-d', strtotime($options['datumbis']." days"));

	$url = "https://www.pccaddie.net/interface/platzbelegung.php?user=".$options['pcuser']."&password=".$options['pcpassword']."&club=".$options['pcclub']."&datumvon=".$startdate."&datumbis=".$enddate."&minentries=".$options['pcminentries']."&showjson=1&maxentries=".$options['pcmaxentries']."&dayinfo=0";

	$JSON = file_get_contents($url);
	$data = json_decode($JSON,true);
 
	if(isset($data)){
		foreach ($data as $key => $value) {	
			if(is_array($value)){
				$explodedDatum = explode("-",$value['DATUM']);
				$explodedDATUM_ENDE = explode("-",$value['DATUM_ENDE']);
				
				// if ? then add &
				if (strpos($options['pclink'],'?') !== false) {
				    $pcurl = $options['pclink']."&";
				} else {
				    $pcurl = $options['pclink']."?";
				}
                        $html .=   "<div class=\"snapshot-col\">".
                            "<div class=\"snapshot-default\">".
                                "<p class=\"snapshot-date\"><span class=\"day\">".$explodedDatum['2']."</span>".
                                "<span class=\"month\">/".$explodedDatum['1']."</span>".
                                "</p>".
                                "<p class=\"snapshot-name\">".$value['TURNIERNAME']."</p>".
                                "<p class=\"snapshot-link\"><a href=\"".$pcurl."&turnierid=".$value['TURNIERID'].
                                "&pccmobileclubID=".$options['pcclub']."\">".$options['pcbuttonText']."</a></p>".
                            "</div>

                            <div class=\"snapshot-appear\">".
                                "<p class=\"snapshot-date\">".
                                "<span class=\"day\">".$explodedDatum['2']."</span>".
                                "<span class=\"month\">/".$explodedDatum['1']."</span>".
                                "<span class=\"year\">/".$explodedDatum['0']."</span></p>".
                                "<p class=\"snapshot-name\">".$value['TURNIERNAME']."</p>".
                                "<p class=\"snapshot-info\">".$value['STARTINFO']."</p>".
                                "<p class=\"snapshot-entry\">".$value['MELDUNG_AB']."</p>";
                                // Entry to early
                                if (!empty($value['MELDUNG_AB']) && strtotime($value['MELDUNG_AB']) <= time())
                                {
                                     $html .= "<p class=\"snapshot-entrystart\">Anmeldung ab: " . date("d.m.Y H:i", strtotime($value['MELDUNG_AB'])) . "</p>";
                                }
                                if (!empty($value['MELDESCHLUSS']))
                                {
                                    $html .=  "<p class=\"snapshot-entryend\">Anmeldung bis: " . date("d.m.Y H:i", strtotime($value['MELDESCHLUSS'])) . "</p>";
                                }

                $html .=   "<p class=\"snapshot-endtime\">Ende: ".$explodedDATUM_ENDE['1']."-".$explodedDATUM_ENDE['2']."-".$explodedDATUM_ENDE['0']." ".$value['TIME_END']."</p>".
                                "<p class=\"snapshot-starttime\">Start: ".$value['TIME_START']."</p>".
                                "<p class=\"snapshot-link\">".
                                "<a href=\"".$pcurl."&turnierid=".$value['TURNIERID'].
                                "&pccmobileclubID=".$options['pcclub']."\">".$options['pcbuttonText']."</a></p>".
                            "</div>".
                        "</div>"; 

	// 			        //"MELDESCHLUSS":"",
 //                        //"STARTLISTE":0,
 //                        //"ERGEBNISLISTE":0,
 //                        //"TURNIERNAME":"OASIS Cup",
 //                        //"TURNIERID":"182115",
 //                        //"MELDUNG_AB":"",
 //                        // "OFFEN_INTERN":"I",
 //                        // "TIME_START":"",
			} 
		}
        return $html;
	}
	


}
add_shortcode( 'pccosnapshot', 'pccaddie_func' );


function pccaddie_login()
{
	$classpcc = new Pccaddie;
	return $classpcc->onContentPrepare();
}

add_shortcode( 'pccologin', 'pccaddie_login' );

// Teetimes
function pccaddie_iframe_teetimes(){
	$classpcc = new Pccaddie;
	return $classpcc->pc_iframe('teetimes');
}
add_shortcode( 'pccoiframe_teetimes', 'pccaddie_iframe_teetimes' );

// Trainer
function pccaddie_iframe_trainer(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('trainer');
}
add_shortcode( 'pccoiframe_trainer', 'pccaddie_iframe_trainer' );

// Trainerweek
function pccaddie_iframe_trainerweek(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('trainerweek');
}
add_shortcode( 'pccoiframe_trainerweek', 'pccaddie_iframe_trainerweek' );

// Kalender
function pccaddie_iframe_calendar(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('calendar');
}
add_shortcode( 'pccoiframe_calendar', 'pccaddie_iframe_calendar' );

// Startlist
function pccaddie_iframe_startlist(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('startlist');
}
add_shortcode( 'pccoiframe_startlist', 'pccaddie_iframe_startlist' );

// Resultate
function pccaddie_iframe_resultlist(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('resultlist');
}
add_shortcode( 'pccoiframe_resultlist', 'pccaddie_iframe_resultlist' );

// Turnieranmeldung
function pccaddie_iframe_entry(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('entry');
}
add_shortcode( 'pccoiframe_entry', 'pccaddie_iframe_entry' );

// HCP List
function pccaddie_iframe_hcplist(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('hcplist');
}
add_shortcode( 'pccoiframe_hcplist', 'pccaddie_iframe_hcplist' );

// Memberverzeichnis
function pccaddie_iframe_memberlist(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('memberlist');
}
add_shortcode( 'pccoiframe_memberlist', 'pccaddie_iframe_memberlist' );

// Member Daten �ndern
function pccaddie_iframe_memberdata(){
    $classpcc = new Pccaddie;
    return $classpcc->pc_iframe('memberdata');
}
add_shortcode( 'pccoiframe_memberdata', 'pccaddie_iframe_memberdata' );
