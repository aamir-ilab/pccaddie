<?php
/*=========================  Add user restriction  ======================== */
function user_meta_box_restriction($object)
{
    wp_nonce_field(basename(__FILE__), "meta-box-nonce");

    ?>
    <div>
        <?php
        $checkbox_value = get_post_meta($object->ID, "user-restriction", true);
        $user_zus = get_post_meta($object->ID, "user-zus", true);
        ?>
        <p><label for="user-zus">Nur sichbar wenn ZUSATZINFO enthalten:</label>
            <input name="user-zus" type="text" value="<?=$user_zus?>"></p>

        <p><label for ="user-restriction">Nur für Mitglieder einsehbar</label>
            <?php
            if($checkbox_value == "")
            {
                ?>
                <input name="user-restriction" type="checkbox" value="true">
                <?php
            }
            else if($checkbox_value == "true")
            {
            ?>
            <input name="user-restriction" type="checkbox" value="true" checked></p>
    <?php
    }
    ?>
    </div>
    <?php
}

function add_restriction_meta_box()
{
    add_meta_box("restriction-meta-box", "PC CADDIE://online Zugriffsschutz", "user_meta_box_restriction", "page", "side", "high", null);
}

add_action("add_meta_boxes", "add_restriction_meta_box");

function save_restriction_meta_box($post_id, $post, $update)
{
    if (!isset($_POST["meta-box-nonce"]) || !wp_verify_nonce($_POST["meta-box-nonce"], basename(__FILE__)))
        return $post_id;

    if(!current_user_can("edit_post", $post_id))
        return $post_id;

    if(defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;

    $slug = "page";
    if($slug != $post->post_type)
        return $post_id;

    $meta_box_checkbox_value = "";

    if(isset($_POST["user-restriction"]))
    {
        $meta_box_checkbox_value = $_POST["user-restriction"];
    }
    update_post_meta($post_id, "user-restriction", $meta_box_checkbox_value);

    if(isset($_POST["user-zus"]))
    {
        $meta_box_zus_value = $_POST["user-zus"];
    }
    update_post_meta($post_id, "user-zus", $meta_box_zus_value);
}

add_action("save_post", "save_restriction_meta_box", 10, 3);


function rr_404_my_event() {
    global $post;
    global $wp_query;
    if( get_post_meta(@$post->ID, 'user-restriction', true ) ) {
        $classpcc = new Pccaddie;
        $member = $classpcc->get("PC_IS_MEMBER");
        $dbmember = get_post_meta(@$post->ID, 'user-restriction', true );
        if($dbmember==true && $member!=1){
            // $wp_query->set_404();
            // status_header(404);
            wp_safe_redirect( add_query_arg( 'private', '1', wp_login_url( $_SERVER['REQUEST_URI'] )));
            exit;
        }
    }

    if( get_post_meta(@$post->ID, 'user-zus', true ) ) {
        $classpcc = new Pccaddie;
        $ZUSATZ = $classpcc->get("PC_ZUSATZ");
        $zus = get_post_meta(@$post->ID, 'user-zus', true );
        if (strpos($ZUSATZ,$zus ) != true) {
            // $wp_query->set_404();
            // status_header(404);
            wp_safe_redirect( add_query_arg( 'private', '1', wp_login_url( $_SERVER['REQUEST_URI'])));
            exit;
        }
    }

}
add_action( 'wp', 'rr_404_my_event' );


add_filter( 'login_message', 'my_private_page_login_message' );

function my_private_page_login_message( $message ) {
    if ( isset( $_REQUEST['private'] ) && $_REQUEST['private'] == 1 )
        $message .= sprintf( '<p class="message">%s</p>', __( 'The page you tried to visit is restricted. Please log in or register to continue.' ) );
    return $message;
}

if(isset($_GET['private']) == 1){
    echo "
    <style>
        .login form {
            display:none ;
        }

        .login #nav {
            display:none ;
        }
    </style>
    ";
}